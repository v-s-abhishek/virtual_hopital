package com.ooad;

import org.springframework.data.jpa.repository.JpaRepository;


public interface invoiceRepository extends JpaRepository<invoice,Integer> {

}